

<?php $__env->startSection('content'); ?>

<div class="container" style="margin-top:100px;">
  
  <div class="container" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="content">
                <div class="body p-4">
                    <div class="px-4 py-5">
                        <h5 class="text-uppercase"><?php echo e($dataOrderAndCustomer->customer->name); ?></h5>
                        <div class="d-flex justify-content-between">
                            <span class="text-dark">Tanggal Order</span>
                            <span class="text-dark"><?php echo e($newDate); ?></span>
                        </div>
                        <h4 class="mt-5 theme-color mb-5">Terima Kasih</h4>
                        <div class="d-flex justify-content-between">
                            <span class="theme-color">Tanggal Beli</span>
                            <span class="theme-color"><?php echo e($dataOrderAndCustomer->tgl_pesanan); ?></span>
                        </div>
                        <div class="mb-3">
                            <hr class="new1">
                        </div>
                        <div class="d-flex flex-column gap-3">
                            <?php $__currentLoopData = $orderDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex justify-content-between">
                                <span class="fw-bold "><?php echo e($item->product->nama_product); ?> (Qty:<?php echo e($item->quantity); ?>) </span>
                                <span class="text-muted"><?php echo formatRupiah($item->product->harga_product); ?></span>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="mb-3">
                            <hr class="new1">
                        </div>
                        <div class="d-flex justify-content-between mt-3">
                            <span class="fw-bold fs-5">Total</span>
                            <span class="fw-bold theme-color"><?php echo formatRupiah($dataOrderAndCustomer->total); ?></span>
                        </div>                  
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</div>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('addCss'); ?>
<style>
  .table-primary {
    background-color: #F0861A !important;
    border: none;
  }
  .theme-color{

color: #F0861A;
}
hr.new1 {
border-top: 2px dashed #000000;
margin: 0.4rem 0;
}



</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\Ecomerce\user-service\resources\views/user/list-order-jual-detail.blade.php ENDPATH**/ ?>