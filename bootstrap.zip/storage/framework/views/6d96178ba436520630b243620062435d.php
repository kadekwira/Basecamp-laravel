
<?php $__env->startSection('content'); ?>
<div class="main-content">
  <section class="section">
    <div class="section-header">
      <h1>Edit Data Pesanan</h1>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="card">
          <form method="post" action="<?php echo e(route('order-sewa.update', $order->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?> 

            <div class="card-header">
              <h4>Edit Data Pesanan</h4>
            </div>
            <div class="card-body row">
              <div class="col-12">
                <div class="form-group">
                  <label>Nama Pelanggan</label>
                  <select class="form-control" id="id_customer" name="id_customer" required>
                    <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <option value="<?php echo e($customer->id); ?>" <?php echo e($customer->id == $order->id_customer ? 'selected' : ''); ?>>
                        <?php echo e($customer->name); ?>

                      </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <option value="">Data Tidak Tersedia</option>
                    <?php endif; ?>
                  </select>
                </div>
              </div>
              <div class="col-12">
                <div class="form-group">
                  <label>Product</label>
                  <select class="form-control" id="id_product" name="id_product" required>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <option value="<?php echo e($product->id); ?>" 
                              data-price="<?php echo e($product->harga_product); ?>"
                              data-hilang="<?php echo e($product->harga_hilang); ?>"
                              data-telat="<?php echo e($product->harga_telat); ?>"
                              data-rusak="<?php echo e($product->harga_rusak); ?>"
                              <?php echo e($product->id == $order->id_product ? 'selected' : ''); ?>>
                        <?php echo e($product->nama_product); ?>

                      </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <option value="">Data Tidak Tersedia</option>
                    <?php endif; ?>
                  </select>
                </div>
              </div>
              <div class="col-4">
                <div class="form-group">
                  <label>Jumlah Product</label>
                  <input type="number" class="form-control" id="jumlah" name="jumlah" value="<?php echo e($order->jumlah); ?>" required >
                </div>
              </div>
              <div class="col-4">
                <div class="form-group">
                  <label>Tanggal Pesanan</label>
                  <input type="date" class="form-control" id="tgl_pesanan" name="tgl_pesanan" value="<?php echo e($order->tgl_pesanan); ?>" required >
                </div>
              </div>
              <div class="col-4">
                <div class="form-group">
                  <label>Tanggal Kembali</label>
                  <input type="date" class="form-control" id="tgl_kembali" name="tgl_kembali" value="<?php echo e($order->tgl_kembali); ?>" required >
                </div>
              </div>
              <div class="col-12">
                <div class="form-group">
                  <label>Harga Product</label>
                  <input type="text" class="form-control" id="harga_product" name="harga_product" value="<?php echo e($order->harga_product); ?>" required readonly>
                </div>
              </div>
              <div class="col-12">
                <div class="form-group">
                  <label>Harga Hilang</label>
                  <input type="text" class="form-control" id="harga_hilang" name="harga_hilang" value="<?php echo e($order->harga_hilang); ?>" required readonly>
                </div>
              </div>
              <div class="col-12">
                <div class="form-group">
                  <label>Harga Telat</label>
                  <input type="text" class="form-control" id="harga_telat" name="harga_telat" value="<?php echo e($order->harga_telat); ?>" required readonly>
                </div>
              </div>
              <div class="col-12">
                <div class="form-group">
                  <label>Harga Rusak</label>
                  <input type="text" class="form-control" id="harga_rusak" name="harga_rusak" value="<?php echo e($order->harga_rusak); ?>" required readonly>
                </div>
              </div>
              <div class="col-12">
                <div class="form-group">
                  <label>Harga Total</label>
                  <input type="text" class="form-control" id="total" name="total" value="<?php echo e($order->total); ?>" required readonly>
                </div>
              </div>
              <div class="col-12">
                <div class="form-group">
                  <label>Note</label>
                  <input type="text" class="form-control" id="note" name="note" value="<?php echo e($order->note); ?>">
                </div>
              </div>
            </div>
            <div class="card-footer text-right">
              <button class="btn btn-primary">Submit</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addJavascript'); ?>
<script>
  function formatRupiah(angka, prefix) {
    var numberString = angka.replace(/[^,\d]/g, '').toString(),
      split = numberString.split(','),
      sisa = split[0].length % 3,
      rupiah = split[0].substr(0, sisa),
      ribuan = split[0].substr(sisa).match(/\d{3}/gi);

    if (ribuan) {
      separator = sisa ? '.' : '';
      rupiah += separator + ribuan.join('.');
    }

    rupiah = split[1] !== undefined ? rupiah + ',' + split[1] : rupiah;
    return prefix === undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
  }

  $(document).ready(function() {
    function updatePrices() {
      var selectedProduct = $('#id_product').find('option:selected');
      var price = selectedProduct.data('price').toString();
      var hilang = selectedProduct.data('hilang').toString();
      var telat = selectedProduct.data('telat').toString();
      var rusak = selectedProduct.data('rusak').toString();
      var jumlah = $('#jumlah').val();
      var total = (parseFloat(price.replace(/[^,\d]/g, '')) * parseInt(jumlah)).toString();

      $('#harga_product').val(formatRupiah(price, 'Rp. '));
      $('#harga_hilang').val(formatRupiah(hilang, 'Rp. '));
      $('#harga_telat').val(formatRupiah(telat, 'Rp. '));
      $('#harga_rusak').val(formatRupiah(rusak, 'Rp. '));
      $('#total').val(formatRupiah(total, 'Rp. '));
    }

    $('#id_product').change(updatePrices);
    $('#jumlah').on('input', updatePrices);

    // Trigger change event on page load to set initial prices if needed
    $('#id_product').trigger('change');
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\Ecomerce\user-service\resources\views/admin/orderSewa/edit.blade.php ENDPATH**/ ?>