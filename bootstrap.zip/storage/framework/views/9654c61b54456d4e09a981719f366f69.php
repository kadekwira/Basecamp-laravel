
<?php $__env->startSection('content'); ?>
<div class="main-content">
  <section class="section">
    <div class="section-header">
      <h1>Order Detail</h1>
    </div>

    <div class="section-body">
      <div class="invoice">
        <div class="invoice-print">
          <div class="row">
            <div class="col-lg-12">
              <div class="invoice-title">
                <h2>Order Detail</h2>
                <div class="invoice-number">Order #<?php echo e($id); ?></div>
              </div>
              <hr>
              <div class="row">
                <div class="col-md-6">
                  <address>
                    <strong>Pelanggan:</strong><br>
                      <?php echo e($dataOrderAndCustomer->customer->name); ?><br>
                      <?php echo e($dataOrderAndCustomer->customer->phone); ?><br>
                      <?php echo e($dataOrderAndCustomer->tgl_pesanan); ?><br>
                      <?php echo e($dataOrderAndCustomer->customer->address); ?>

                  </address>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6">
                  <address>
                    <strong>Tanggal Order:</strong><br>
                    <?php echo e($newDate); ?><br><br>
                  </address>
                </div>
              </div>
            </div>
          </div>
          
          <div class="row mt-4">
            <div class="col-md-12">
              <div class="section-title">List Order</div>
              <p class="section-lead">Semua barang disini tidak bisa di hapus</p>
              <div class="table-responsive">
                <table class="table table-striped table-hover table-md">
                  <tr>
                    <th data-width="40">#</th>
                    <th>Produk</th>
                    <th class="text-center">Harga</th>
                    <th class="text-center">Jumlah</th>
                    <th class="text-right">Total</th>
                  </tr>
                  <?php
                      $no=1;
                  ?>
                  <?php $__currentLoopData = $orderDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($no); ?></td>
                    <td><?php echo e($item->product->nama_product); ?></td>
                    <td class="text-center"><?php echo formatRupiah($item->product->harga_product); ?></td>
                    <td class="text-center"><?php echo e($item->quantity); ?></td>
                    <td class="text-right"><?php echo formatRupiah($item->price); ?></td>
                  </tr>
                  <?php
                      $no++;
                  ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
              </div>
              <div class="row mt-4">
                  <hr class="mt-2 mb-2">
                  <div class="invoice-detail-item">
                    <div class="invoice-detail-name">Total</div>
                    <div class="invoice-detail-value invoice-detail-value-lg"><?php echo formatRupiah($dataOrderAndCustomer->total); ?></div>
                  </div>
                </div>
              </div>
            </div>
            <hr>
            <div class="text-md-right">
              <div class="float-lg-right mb-lg-0 mb-3">
                <form action="<?php echo e(route('order-jual.tolak', $id)); ?> " method="POST" style="display: inline;">'
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="_method" value="PUT">
                  <button type="submit" class="btn btn-icon btn-danger"><i class="far fa-times-circle"></i>Tolak</button>
              </form>
                <form action="<?php echo e(route('order-jual.acc',$id)); ?>" method="POST" style="display: inline;">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="_method" value="PUT">
                  <button type="submit" class="btn btn-icon btn-success"><i class="far fa-check-circle"></i> Terima</button>
              </form>
   
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('addCss'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('addJavascript'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\Ecomerce\user-service\resources\views/admin/orderJual/detail.blade.php ENDPATH**/ ?>