<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Project\Ecomerce\user-service\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>