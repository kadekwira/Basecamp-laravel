
<?php $__env->startSection('content'); ?>
<div class="main-content">
  <section class="section">
    <div class="section-header">
      <h1>Data Produk Sewa</h1>
    </div>
    <div class="row">
      <div class="col-12 ">
        <div class="card">
          <form method="post" action="<?php echo e(route('product-sewa.update',$data->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="card-header">
              <h4>Edit Data Produk Sewa</h4>
            </div>
            <div class="card-body row">
              <div class="col-12">
                <div class="form-group">
                  <input type="hidden" class="form-control" name="image_old" value="<?php echo e($data->image); ?>">
                  <div id="photo-preview-container" style="display: <?php echo e($data->image ? 'block' : 'none'); ?>">
                    <img id="photo-preview" src="<?php echo e($data->image ? asset('storage/' . $data->image) : ''); ?>" alt="your image" style="display: <?php echo e($data->image ? 'block' : 'none'); ?>"/>
                    <button type="button" id="remove-photo" class="btn btn-sm btn-danger" style="display: <?php echo e($data->image ? 'inline-block' : 'none'); ?>"><i class="fas fa-times"></i></button>
                  </div>
                  <label>Gambar Produk</label>
                  <input type="file" class="form-control" name="image" id="image" accept="image/*">
                </div>
              </div>
              <div class="col-12">
                <div class="form-group">
                  <label> Nama Produk</label>
                  <input type="text" class="form-control" required=""
                  name="nama_product"  value="<?php echo e($data->nama_product); ?>"
                  >
                </div>
              </div>
              <div class="col-12">
                <div class="form-group">
                  <label>Harga Produk</label>
                  <input type="text" class="form-control" name="harga_product" id="harga_product" required value="<?php echo formatRupiah($data->harga_product); ?>">
                </div>
              </div>
              <div class="col-12">
                <div class="form-group">
                  <label>Deskripsi Produk</label>
                  <input type="text" class="form-control" name="deskripsi"  required value="<?php echo e($data->deskripsi); ?>">
                </div>
              </div>
              <div class="col-4">
                <div class="form-group">
                  <label>Stock</label>
                  <input type="number" class="form-control" name="stock" required value="<?php echo e($data->stock); ?>">
                </div>
              </div>
              <div class="col-12">
                <div class="form-group">
                    <label>Status</label>
                    <select class="form-control" id="status" name="status" required>
                        <option value="active" <?php echo e($data->status == 'active' ? 'selected' : ''); ?>>Active</option>
                        <option value="inactive" <?php echo e($data->status == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                    </select>
                </div>
               </div>
            </div>
            <div class="card-footer text-right">
              <a href="<?php echo e(route('product-sewa.index')); ?>" class="btn btn-danger">Batal</a>
              <button class="btn btn-primary">Submit</button>
            </div>
          </form>
        </div>
      </div>
      </div>
    </div>
  </section>
</div>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('addCss'); ?>
<style>
  #photo-preview-container {
      position: relative;
      width: 200px; 
      height: 200px; 
      overflow: hidden;
      margin-bottom: 10px;
  }
  #photo-preview {
      display: block;
      width: 100%;
      height: 100%;
      border-radius: 50%;
  }
  #remove-photo {
      position: absolute;
      top: 2px;
      right: 2px;
      display: none;
  }
</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('addJavascript'); ?>
<script>
  document.addEventListener('DOMContentLoaded', function() {
      var input = document.getElementById('image');
      var previewContainer = document.getElementById('photo-preview-container');
      var preview = document.getElementById('photo-preview');
      var removeButton = document.getElementById('remove-photo');
      var oldPhoto = "<?php echo e($data->image ? asset('storage/' . $data->image) : ''); ?>";

      // Tampilkan foto lama saat halaman dimuat
      if (oldPhoto) {
          preview.src = oldPhoto;
          previewContainer.style.display = 'block';
          preview.style.display = 'block';
          removeButton.style.display = 'inline-block';
      }

      input.addEventListener('change', function(event) {
          var reader = new FileReader();
          reader.onload = function() {
              preview.src = reader.result;
              previewContainer.style.display = 'block';
              preview.style.display = 'block';
              removeButton.style.display = 'inline-block';
          };
          reader.readAsDataURL(event.target.files[0]);
      });

      removeButton.addEventListener('click', function() {
          preview.src = '';
          previewContainer.style.display = 'none';
          preview.style.display = 'none';
          removeButton.style.display = 'none';
          input.value = '';
      });
  });
</script>

<script>
  var input = document.getElementById('harga_product');
  input.addEventListener('keyup', function(e) {
      var bilangan = e.target.value.replace(/[^,\d]/g, '').toString(),
          split = bilangan.split(','),
          sisa = split[0].length % 3,
          rupiah = split[0].substr(0, sisa),
          ribuan = split[0].substr(sisa).match(/\d{1,3}/gi);
  
      if (ribuan) {
          separator = sisa ? '.' : '';
          rupiah += separator + ribuan.join('.');
      }
  
      rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
      var formattedValue = 'Rp. ' + rupiah; // Menambahkan prefix "Rp." secara default
      input.value = formattedValue;
  });
  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\Ecomerce\user-service\resources\views/admin/dataProductSewa/edit.blade.php ENDPATH**/ ?>