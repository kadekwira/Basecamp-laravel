
<?php $__env->startSection('content'); ?>
<div class="main-content">
  <section class="section">
    <div class="section-header">
      <h1>Data Pelanggan</h1>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="card">
          <form method="post" action="<?php echo e(route('customers.update', $data->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="card-header">
              <h4>Edit Data Pelanggan</h4>
            </div>
            <div class="card-body row">
              <div class="col-12">
                <div class="form-group">
                  <input type="hidden" class="form-control" name="image_old" value="<?php echo e($data->ktp); ?>">
                  <div id="photo-preview-container" style="display: <?php echo e($data->ktp ? 'block' : 'none'); ?>">
                    <img id="photo-preview" src="<?php echo e($data->ktp ? asset('storage/' . $data->ktp) : ''); ?>" alt="your image" style="display: <?php echo e($data->ktp ? 'block' : 'none'); ?>"/>
                    <button type="button" id="remove-photo" class="btn btn-sm btn-danger" style="display: <?php echo e($data->ktp ? 'inline-block' : 'none'); ?>"><i class="fas fa-times"></i></button>
                  </div>
                  <label>Foto</label>
                  <input type="file" class="form-control" name="ktp" id="image" accept="image/*">
                </div>
              </div>
              <div class="col-12">
                <div class="form-group">
                  <label> Nama</label>
                  <input type="text" class="form-control" required=""
                  name="name" value="<?php echo e($data->name); ?>"
                  >
                </div>
              </div>
              <div class="col-12">
                <div class="form-group">
                  <label>Email</label>
                  <input type="email" class="form-control" name="email" required value="<?php echo e($data->email); ?>">
                </div>
              </div>
              <div class="col-4">
                <div class="form-group">
                  <label>No Telp</label>
                  <input type="number" class="form-control" name="phone" required value="<?php echo e($data->phone); ?>">
                </div>
              </div>
              <div class="col-8">
                <div class="form-group">
                  <label>Alamat</label>
                  <input type="text" class="form-control" name="address" required value="<?php echo e($data->address); ?>">
                </div> 
              </div>
              <div class="col-12">
                <div class="form-group">
                  <label>Role </label>
                  <select class="form-control" id="role" name="role" required>
                    <option value="">Select Role</option>
                    <option value="customer" <?php echo e($data->role == 'customer' ? 'selected' : ''); ?>>Customer</option>
                </select>
                </div>
              </div>
              <div class="col-12">
                <div class="form-group">
                    <label>Status</label>
                    <select class="form-control" id="status" name="status" required>
                        <option value="active" <?php echo e($data->status == 'active' ? 'selected' : ''); ?>>Active</option>
                        <option value="inactive" <?php echo e($data->status == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                    </select>
                </div>
               </div>
            
            </div>
            <div class="card-footer text-right">
              <a href="<?php echo e(route('customers.index')); ?>" class="btn btn-danger">Batal</a>
              <button class="btn btn-primary">Simpan</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addCss'); ?>
<style>
  #photo-preview-container {
      position: relative;
      width: 200px; 
      height: 200px; 
      overflow: hidden;
      margin-bottom: 10px;
  }
  #photo-preview {
      display: block;
      width: 100%;
      height: 100%;
      border-radius: 50%;
  }
  #remove-photo {
      position: absolute;
      top: 2px;
      right: 2px;
      display: none;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addJavascript'); ?>
<script>
  document.addEventListener('DOMContentLoaded', function() {
      var input = document.getElementById('image');
      var previewContainer = document.getElementById('photo-preview-container');
      var preview = document.getElementById('photo-preview');
      var removeButton = document.getElementById('remove-photo');
      var oldPhoto = "<?php echo e($data->ktp ? asset('storage/' . $data->ktp) : ''); ?>";

      // Tampilkan foto lama saat halaman dimuat
      if (oldPhoto) {
          preview.src = oldPhoto;
          previewContainer.style.display = 'block';
          preview.style.display = 'block';
          removeButton.style.display = 'inline-block';
      }

      input.addEventListener('change', function(event) {
          var reader = new FileReader();
          reader.onload = function() {
              preview.src = reader.result;
              previewContainer.style.display = 'block';
              preview.style.display = 'block';
              removeButton.style.display = 'inline-block';
          };
          reader.readAsDataURL(event.target.files[0]);
      });

      removeButton.addEventListener('click', function() {
          preview.src = '';
          previewContainer.style.display = 'none';
          preview.style.display = 'none';
          removeButton.style.display = 'none';
          input.value = '';
      });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\Ecomerce\user-service\resources\views/admin/dataPelanggan/edit.blade.php ENDPATH**/ ?>