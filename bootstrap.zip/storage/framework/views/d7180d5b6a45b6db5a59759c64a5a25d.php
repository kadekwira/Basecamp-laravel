

<?php $__env->startSection('content'); ?>

<div class="container" style="margin-top:100px;">
  <div class="table-responsive">
    <table class="table table-striped">
      <thead>
        <tr class="text-center ">
          <th scope="col">#</th>
          <th scope="col">Tanggal Pesanan</th>
          <th scope="col">Tanggal Pembayaran</th>
          <th scope="col">Status Pembelian</th>
          <th scope="col">Total</th>
          <th scope="col">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr class="text-center ">
          <th class="py-3"><?php echo e($index+1); ?></th>
          <td class="py-3"><?php echo e($item->tgl_pesanan); ?></td>
          <td class="py-3"><?php echo e($item->tgl_pembayaran); ?></td>
          <td class="py-3">
            <?php if($item->status=='terima'): ?>
            <span class="badge bg-success"><?php echo e($item->status); ?></span>
            <?php elseif($item->status=='tolak'): ?>
            <span class="badge bg-danger"><?php echo e($item->status); ?></span>
            <?php else: ?>
            <span class="badge bg-warning"><?php echo e($item->status); ?></span> 
            <?php endif; ?>
          </td>
          <td class="py-3"><?php echo formatRupiah($item->total); ?></td>
          <td class="py-3">
            <a href="<?php echo e(route('order.jual.detail',$item->id)); ?>" class="bg-primary p-2 rounded text-white" style="text-decoration: none !important;">
              Detail
            </a>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="6" class="text-center">Data Not Available</td>
            </tr>
        <?php endif; ?>
  
      </tbody>
    </table>
  </div>
</div>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('addCss'); ?>
<style>
  .table-primary {
    background-color: #F0861A !important;
    border: none;
  }

</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\Ecomerce\user-service\resources\views/user/list-order-jual.blade.php ENDPATH**/ ?>