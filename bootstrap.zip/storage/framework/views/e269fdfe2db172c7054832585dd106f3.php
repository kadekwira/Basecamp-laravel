
<?php $__env->startSection('content'); ?>
<div class="main-content">
  <section class="section">
    <div class="section-header">
      <h1>Data Produk Sewa</h1>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <a href="<?php echo e(route('product-sewa.create')); ?>" class="btn btn-icon btn-success ml-auto button-header-add"><i class="fas fa-plus"></i></a>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-striped" id="tableDataAdmin">
                <thead>                                 
                  <tr class="text-center">
                    <th>No</th>
                    <th>Nama Produk</th>
                    <th>Gambar Produk</th>
                    <th>Stock</th>
                    <th>Harga Produk</th>
                    <th>Deskripsi</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody> 
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addCss'); ?>
<link rel="stylesheet" href="<?php echo e(asset('newAdmin/dist/assets/modules/datatables/datatables.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('newAdmin/dist/assets/modules/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('newAdmin/dist/assets/modules/datatables/Select-1.2.4/css/select.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addJavascript'); ?>
<script src="<?php echo e(asset('newAdmin/dist/assets/modules/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('newAdmin/dist/assets/modules/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('newAdmin/dist/assets/modules/datatables/Select-1.2.4/js/dataTables.select.min.js')); ?>"></script>
<script src="<?php echo e(asset('newAdmin/dist/assets/modules/jquery-ui/jquery-ui.min.js')); ?>"></script>

<script>
  $(document).ready(function() {
    $('#tableDataAdmin').DataTable({
      processing: true,
      serverSide: true,
      ajax: {
        url: '<?php echo e(route('product-sewa.index')); ?>',
        type: 'GET'
      },
      columns: [
        { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false,className: 'text-center' },
        { data: 'nama_product', name: 'nama_product',className: 'text-center' },
        { data: 'image', name: 'image',className: 'text-center' },
        { data: 'stock', name: 'stock' ,className: 'text-center'},
      
        { data: 'harga_product', name: 'harga_product', render: $.fn.dataTable.render.number(',', '.', 0, 'Rp ') ,className: 'text-center'},
        { data: 'deskripsi', name: 'deskripsi' ,className: 'text-center'},
        { data: 'status', name: 'status',className: 'text-center'},
        { data: 'action', name: 'action', orderable: false, searchable: false,className: 'text-center' },
      ]
    });
  });
</script>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Project\Ecomerce\user-service\resources\views/admin/dataProductSewa/index.blade.php ENDPATH**/ ?>